# RINDO 好き顔9選 v4

RINDO Entertainmentのタレント83名を対象にした、スマホ向け「好き顔9選」メーカーです。

## 今回の仕様
- 予選は5人ずつ表示
- 予選は**何人でも選択OK**
- TOP9を作るため、予選は9人以上を選択
- 本選は選んだ人だけで1対1の顔比較
- 比較結果を集計してTOP9を決定
- 結果のコピー
- ブラウザ内保存
- GitHub Pages対応
- 写真は `images/1.jpg` ～ `images/83.jpg` に差し替えるだけ

## 写真について
この配布物にはRINDO公式サイトの写真そのものは同梱していません。
公式写真を使用する場合は、利用規約・著作権・肖像権等を確認したうえで、使用許可や利用条件に従ってください。

各写真は `candidates.json` のIDと対応しています。
例：1番「なめ」→ `images/1.jpg`

写真がまだない状態でも、`placeholder.svg` が自動表示されるので動作確認できます。

## GitHub Pages
1. GitHubで新しいRepositoryを作る
2. このフォルダの中身をアップロード
3. Settings → Pages
4. Deploy from a branch → main / root
5. Save
